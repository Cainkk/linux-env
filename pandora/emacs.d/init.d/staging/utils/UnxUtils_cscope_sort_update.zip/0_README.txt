
update cscope, sort, because sort invoke env, which is bad.

cscope version: 15.8a-32bit
